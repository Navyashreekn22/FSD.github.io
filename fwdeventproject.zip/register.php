<!DOCTYPE html>
<html lang="en">
<head>
    <title>Event Scheduler Site</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo"> docket.com</h2>
            </div>






            

        </div> 
        <div class="content">
            <h1>Event <br>Scheduler <br>Site</h1>
            <p class="par">Book any event anytime, anywhere in Banglore at our event scheduler site docket.com
                 for free. <br> It is easiest, cheapest and hassle free way to book your events.</p>
             

                

                <div class="form">
                    <h2>Register  Here</h2>
					
                    <input type="email" name="email" placeholder="Enter Email ">
					<input type="phone" name="phone" placeholder="Enter phone number ">
                    <input type="password" name="" placeholder="Enter Password ">
					<input type="password" name="" placeholder=" confirm Password ">
                    <button class="btnn"><a href="#">Submit</a></button>
 <button class="btnn"><a href="enterlogin.html">click here to login</a></button>
					
                   
                    
                   

                  

                </div>
                    </div>
                </div>
        </div>
    </div>
    


    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>



</body>
</html>